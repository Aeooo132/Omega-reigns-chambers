import { motion } from 'framer-motion';
import { ChevronRight, Shield, Award, Users } from 'lucide-react';

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-[var(--off-white)] via-[var(--warm-gray)] to-white">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-20 w-32 h-32 border border-[var(--regal-purple)] rounded-full"></div>
        <div className="absolute top-40 right-32 w-24 h-24 border border-[var(--regal-gold)] rounded-full"></div>
        <div className="absolute bottom-32 left-1/4 w-16 h-16 border border-[var(--regal-light-purple)] rounded-full"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="space-y-8"
        >
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="inline-flex items-center px-4 py-2 rounded-full bg-[var(--regal-purple)]/10 text-[var(--regal-purple)] border border-[var(--regal-purple)]/20"
          >
            <Award className="w-4 h-4 mr-2" />
            <span className="text-sm font-medium">Award-Winning Legal Excellence</span>
          </motion.div>

          {/* Main Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-[var(--regal-navy)] leading-tight max-w-5xl mx-auto"
          >
            Defending Your Rights with
            <motion.span
              className="block text-[var(--regal-purple)] bg-gradient-to-r from-[var(--regal-purple)] to-[var(--regal-light-purple)] bg-clip-text text-transparent"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 1 }}
            >
              Unwavering Excellence
            </motion.span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="text-lg sm:text-xl text-[var(--muted-foreground)] max-w-3xl mx-auto leading-relaxed"
          >
            For over three decades, Sterling & Associates has provided premier legal representation 
            to individuals and businesses across the nation. Your success is our commitment.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4"
          >
            <motion.button
              className="group bg-[var(--regal-purple)] text-white px-8 py-4 rounded-lg text-lg font-medium flex items-center space-x-2 hover:bg-[var(--regal-light-purple)] transition-all duration-200 shadow-lg hover:shadow-xl"
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
            >
              <span>Schedule Free Consultation</span>
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-200" />
            </motion.button>
            
            <motion.button
              className="group border-2 border-[var(--regal-purple)] text-[var(--regal-purple)] px-8 py-4 rounded-lg text-lg font-medium hover:bg-[var(--regal-purple)] hover:text-white transition-all duration-200"
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
            >
              Learn More About Us
            </motion.button>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.2 }}
            className="grid grid-cols-1 sm:grid-cols-3 gap-8 pt-16"
          >
            {[
              { icon: Shield, number: '30+', label: 'Years of Excellence' },
              { icon: Award, number: '500+', label: 'Cases Won' },
              { icon: Users, number: '1000+', label: 'Satisfied Clients' },
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 1.4 + index * 0.1 }}
                className="flex flex-col items-center space-y-2"
                whileHover={{ y: -5 }}
              >
                <div className="w-12 h-12 rounded-full bg-[var(--regal-purple)]/10 flex items-center justify-center">
                  <stat.icon className="w-6 h-6 text-[var(--regal-purple)]" />
                </div>
                <div className="text-2xl font-bold text-[var(--regal-navy)]">{stat.number}</div>
                <div className="text-[var(--muted-foreground)]">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 2 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-6 h-10 border-2 border-[var(--regal-purple)]/30 rounded-full flex justify-center"
        >
          <motion.div
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-1 h-3 bg-[var(--regal-purple)] rounded-full mt-2"
          />
        </motion.div>
      </motion.div>
    </section>
  );
}