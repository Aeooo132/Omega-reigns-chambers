import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { Linkedin, Mail, Phone } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function TeamSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  const attorneys = [
    {
      name: 'Margaret Sterling',
      title: 'Managing Partner',
      specialization: 'Corporate Law & Litigation',
      experience: '25+ Years Experience',
      education: 'Harvard Law School, J.D.',
      image: 'professional lawyer woman',
      bio: 'Margaret founded Sterling & Associates with a vision to provide exceptional legal services. She specializes in complex corporate litigation and has won numerous high-profile cases.',
    },
    {
      name: 'David Chen',
      title: 'Senior Partner',
      specialization: 'Personal Injury & Medical Malpractice',
      experience: '20+ Years Experience',
      education: 'Stanford Law School, J.D.',
      image: 'professional lawyer man asian',
      bio: 'David is a fierce advocate for injury victims, having secured over $30 million in settlements and verdicts for his clients over the past two decades.',
    },
    {
      name: 'Sarah Martinez',
      title: 'Partner',
      specialization: 'Real Estate & Business Law',
      experience: '15+ Years Experience',
      education: 'Columbia Law School, J.D.',
      image: 'professional lawyer woman hispanic',
      bio: 'Sarah brings extensive experience in real estate transactions and business law, helping clients navigate complex property and corporate matters.',
    },
    {
      name: 'Michael Thompson',
      title: 'Associate Partner',
      specialization: 'Criminal Defense & Appeals',
      experience: '12+ Years Experience',
      education: 'Yale Law School, J.D.',
      image: 'professional lawyer man suit',
      bio: 'Michael is a skilled criminal defense attorney known for his meticulous case preparation and courtroom expertise in defending clients\' rights.',
    },
  ];

  return (
    <section id="team" className="py-20 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[var(--regal-navy)] mb-6"
          >
            Meet Our
            <span className="block text-[var(--regal-purple)]">Distinguished Attorneys</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-lg text-[var(--muted-foreground)] max-w-3xl mx-auto leading-relaxed"
          >
            Our team of accomplished attorneys brings decades of combined experience and a proven track record 
            of success in representing clients across diverse legal matters.
          </motion.p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          {attorneys.map((attorney, index) => (
            <motion.div
              key={attorney.name}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.6 + index * 0.2 }}
              whileHover={{ y: -5 }}
              className="group bg-gradient-to-br from-white to-[var(--warm-gray)] rounded-2xl p-8 shadow-lg border border-[var(--border)] hover:shadow-2xl transition-all duration-300 relative overflow-hidden"
            >
              {/* Background decoration */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-[var(--regal-purple)]/10 to-transparent rounded-full transform translate-x-16 -translate-y-16" />

              <div className="flex flex-col sm:flex-row gap-6 relative z-10">
                {/* Photo */}
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  transition={{ type: "spring", stiffness: 400, damping: 10 }}
                  className="flex-shrink-0"
                >
                  <div className="w-32 h-32 rounded-xl overflow-hidden border-4 border-[var(--regal-gold)]/20 group-hover:border-[var(--regal-gold)]/40 transition-colors duration-300">
                    <ImageWithFallback
                      src={`https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=400&fit=crop&crop=face`}
                      alt={attorney.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </motion.div>

                {/* Content */}
                <div className="flex-1 space-y-3">
                  <div>
                    <h3 className="text-xl font-bold text-[var(--regal-navy)] group-hover:text-[var(--regal-purple)] transition-colors duration-300">
                      {attorney.name}
                    </h3>
                    <p className="text-[var(--regal-purple)] font-medium">{attorney.title}</p>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center text-sm text-[var(--muted-foreground)]">
                      <div className="w-2 h-2 rounded-full bg-[var(--regal-gold)] mr-3" />
                      {attorney.specialization}
                    </div>
                    <div className="flex items-center text-sm text-[var(--muted-foreground)]">
                      <div className="w-2 h-2 rounded-full bg-[var(--regal-gold)] mr-3" />
                      {attorney.experience}
                    </div>
                    <div className="flex items-center text-sm text-[var(--muted-foreground)]">
                      <div className="w-2 h-2 rounded-full bg-[var(--regal-gold)] mr-3" />
                      {attorney.education}
                    </div>
                  </div>

                  <p className="text-sm text-[var(--muted-foreground)] leading-relaxed">
                    {attorney.bio}
                  </p>

                  {/* Contact Icons */}
                  <div className="flex space-x-3 pt-2">
                    {[
                      { icon: Mail, href: `mailto:${attorney.name.toLowerCase().replace(' ', '.')}@sterling-law.com` },
                      { icon: Phone, href: 'tel:+1-555-0123' },
                      { icon: Linkedin, href: '#' },
                    ].map((contact, contactIndex) => (
                      <motion.a
                        key={contactIndex}
                        href={contact.href}
                        whileHover={{ scale: 1.1, y: -2 }}
                        whileTap={{ scale: 0.95 }}
                        className="w-8 h-8 rounded-lg bg-[var(--regal-purple)]/10 flex items-center justify-center text-[var(--regal-purple)] hover:bg-[var(--regal-purple)] hover:text-white transition-all duration-200"
                      >
                        <contact.icon className="w-4 h-4" />
                      </motion.a>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1.2 }}
          className="mt-16 text-center"
        >
          <div className="bg-gradient-to-r from-[var(--warm-gray)] to-white rounded-2xl p-8 border border-[var(--border)]">
            <h3 className="text-2xl font-bold text-[var(--regal-navy)] mb-4">Ready to Work with Our Team?</h3>
            <p className="text-lg text-[var(--muted-foreground)] mb-6">
              Schedule a consultation with one of our experienced attorneys today.
            </p>
            <motion.button
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              className="bg-[var(--regal-purple)] text-white px-8 py-3 rounded-lg font-medium hover:bg-[var(--regal-light-purple)] transition-colors duration-200 shadow-lg"
            >
              Schedule Consultation
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}