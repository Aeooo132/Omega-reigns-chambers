
  # Law firm landing page

  This is a code bundle for Law firm landing page. The original project is available at https://www.figma.com/design/HMZ8Fn3sOndIkzHVEDuiic/Law-firm-landing-page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  