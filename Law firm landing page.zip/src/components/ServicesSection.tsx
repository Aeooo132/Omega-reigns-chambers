import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { 
  Building2, 
  Users, 
  Car, 
  Home, 
  Briefcase, 
  Gavel,
  ArrowRight 
} from 'lucide-react';

export function ServicesSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  const services = [
    {
      icon: Building2,
      title: 'Corporate Law',
      description: 'Comprehensive business legal services including mergers, acquisitions, and compliance.',
      features: ['Contract Negotiation', 'Regulatory Compliance', 'M&A Transactions'],
    },
    {
      icon: Users,
      title: 'Personal Injury',
      description: 'Aggressive representation for accident victims and their families.',
      features: ['Auto Accidents', 'Medical Malpractice', 'Wrongful Death'],
    },
    {
      icon: Home,
      title: 'Real Estate',
      description: 'Full-service real estate legal support for buyers, sellers, and investors.',
      features: ['Property Transactions', 'Title Issues', 'Zoning Disputes'],
    },
    {
      icon: Gavel,
      title: 'Criminal Defense',
      description: 'Experienced criminal defense representation for all types of charges.',
      features: ['DUI Defense', 'White Collar Crime', 'Appeals'],
    },
    {
      icon: Briefcase,
      title: 'Employment Law',
      description: 'Protecting workplace rights for both employees and employers.',
      features: ['Discrimination Claims', 'Wage Disputes', 'Contract Review'],
    },
    {
      icon: Car,
      title: 'Insurance Claims',
      description: 'Maximizing insurance settlements and fighting claim denials.',
      features: ['Claim Disputes', 'Bad Faith Cases', 'Policy Review'],
    },
  ];

  return (
    <section id="services" className="py-20 bg-gradient-to-br from-[var(--warm-gray)] to-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[var(--regal-navy)] mb-6"
          >
            Practice Areas
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-lg text-[var(--muted-foreground)] max-w-3xl mx-auto leading-relaxed"
          >
            Our experienced attorneys provide comprehensive legal services across multiple practice areas, 
            ensuring expert representation for all your legal needs.
          </motion.p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.6 + index * 0.1 }}
              whileHover={{ y: -8, scale: 1.02 }}
              className="group bg-white rounded-xl p-8 shadow-lg border border-[var(--border)] hover:shadow-2xl transition-all duration-300 relative overflow-hidden"
            >
              {/* Background Gradient */}
              <div className="absolute inset-0 bg-gradient-to-br from-[var(--regal-purple)]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              
              {/* Content */}
              <div className="relative z-10">
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ type: "spring", stiffness: 400, damping: 10 }}
                  className="w-16 h-16 rounded-xl bg-gradient-to-br from-[var(--regal-purple)] to-[var(--regal-light-purple)] flex items-center justify-center mb-6 group-hover:shadow-lg transition-shadow duration-300"
                >
                  <service.icon className="w-8 h-8 text-white" />
                </motion.div>

                <h3 className="text-xl font-semibold text-[var(--regal-navy)] mb-3 group-hover:text-[var(--regal-purple)] transition-colors duration-300">
                  {service.title}
                </h3>

                <p className="text-[var(--muted-foreground)] mb-4 leading-relaxed">
                  {service.description}
                </p>

                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, featureIndex) => (
                    <motion.li
                      key={feature}
                      initial={{ opacity: 0, x: -20 }}
                      animate={isInView ? { opacity: 1, x: 0 } : {}}
                      transition={{ duration: 0.4, delay: 0.8 + index * 0.1 + featureIndex * 0.05 }}
                      className="flex items-center text-sm text-[var(--muted-foreground)]"
                    >
                      <div className="w-1.5 h-1.5 rounded-full bg-[var(--regal-gold)] mr-3" />
                      {feature}
                    </motion.li>
                  ))}
                </ul>

                <motion.button
                  whileHover={{ x: 4 }}
                  className="group/btn flex items-center text-[var(--regal-purple)] font-medium hover:text-[var(--regal-light-purple)] transition-colors duration-200"
                >
                  Learn More
                  <ArrowRight className="w-4 h-4 ml-2 group-hover/btn:translate-x-1 transition-transform duration-200" />
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1.2 }}
          className="mt-16 text-center"
        >
          <div className="bg-gradient-to-r from-[var(--regal-purple)] to-[var(--regal-light-purple)] rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">Don't See Your Legal Issue Listed?</h3>
            <p className="text-lg mb-6 text-white/90">
              Our experienced attorneys handle a wide range of legal matters. Contact us to discuss your specific needs.
            </p>
            <motion.button
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              className="bg-white text-[var(--regal-purple)] px-8 py-3 rounded-lg font-medium hover:bg-gray-50 transition-colors duration-200 shadow-lg"
            >
              Get Free Consultation
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}