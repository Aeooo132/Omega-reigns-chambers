import svgPaths from "./svg-tt0k7vv3xu";
import imgShadow from "figma:asset/89cdf921196cbb895e0aac0d181588b814ccbbcf.png";
import imgImage14 from "figma:asset/41836e67122912031230d1488bff7f336558878e.png";

function Group236() {
  return (
    <div className="absolute bottom-0 h-[778px] left-[-559px] w-[1184px]">
      <div className="absolute inset-[-10.5%_-7.25%_-10.45%_-6.91%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1352 942">
          <g id="Group 236" opacity="0.45">
            <path d={svgPaths.p37408340} fill="var(--stroke-0, #1E003C)" id="Vector 12" opacity="0.2" />
            <path d={svgPaths.p19dace00} fill="var(--stroke-0, #1E003C)" id="Vector 13" opacity="0.2" />
            <path d={svgPaths.p1bb8b600} fill="var(--stroke-0, #1E003C)" id="Vector 14" opacity="0.2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame235() {
  return (
    <div className="absolute box-border content-stretch flex font-['Lato:Bold',_sans-serif] gap-9 items-center justify-start leading-[0] not-italic p-[8px] text-[18px] text-center text-nowrap top-10 tracking-[0.36px] translate-x-[-50%]" style={{ left: "calc(50% - 61.5px)" }}>
      <div className="flex flex-col justify-center relative shrink-0 text-[#305cde]">
        <p className="leading-[normal] text-nowrap whitespace-pre">Home</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-[#1e003c]">
        <p className="leading-[normal] text-nowrap whitespace-pre">About</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-[#1e003c]">
        <p className="leading-[normal] text-nowrap whitespace-pre">Courses</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-[#1e003c]">
        <p className="leading-[normal] text-nowrap whitespace-pre">Testimonials</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-[#1e003c]">
        <p className="leading-[normal] text-nowrap whitespace-pre">Contact</p>
      </div>
    </div>
  );
}

function ArrowForward() {
  return (
    <div className="relative shrink-0 size-6" data-name="arrow_forward">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="arrow_forward">
          <path d={svgPaths.p54e7200} fill="var(--fill-0, #FFFDFC)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function Frame234() {
  return (
    <div className="absolute bg-[#1e003c] box-border content-stretch flex gap-2.5 inset-[2.38%_0.75%] items-center justify-center px-[50px] py-[18px] rounded-[100px]">
      <div className="flex flex-col font-['Lato:Bold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#fffdfc] text-[20px] text-center text-nowrap tracking-[0.4px]">
        <p className="leading-[normal] whitespace-pre">Start Learning</p>
      </div>
      <ArrowForward />
    </div>
  );
}

function Group234() {
  return (
    <div className="absolute h-[63px] right-[73px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-[27px] w-[268px]">
      <Frame234 />
    </div>
  );
}

function ArrowForward1() {
  return (
    <div className="relative shrink-0 size-6" data-name="arrow_forward">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="arrow_forward">
          <path d={svgPaths.p54e7200} fill="var(--fill-0, #FFFDFC)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function Frame236() {
  return (
    <div className="absolute bg-[#5a7be7] box-border content-stretch flex gap-2.5 inset-[2.38%_-0.56%] items-center justify-center px-[50px] py-[18px] rounded-[100px]">
      <div className="flex flex-col font-['Lato:Bold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#fffdfc] text-[20px] text-center text-nowrap tracking-[0.4px]">
        <p className="leading-[normal] whitespace-pre">See how I do it</p>
      </div>
      <ArrowForward1 />
    </div>
  );
}

function Group235() {
  return (
    <div className="absolute h-[63px] right-[94px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] translate-y-[-50%] w-[268px]" style={{ top: "calc(50% + 164.5px)" }}>
      <Frame236 />
    </div>
  );
}

function Photo() {
  return (
    <div className="absolute contents left-12 top-[71px]" data-name="photo">
      <div className="absolute flex h-[1122px] items-center justify-center left-12 mix-blend-luminosity top-[102px] w-[748px]">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <div className="bg-center bg-contain bg-no-repeat h-[1122px] opacity-50 w-[748px]" data-name="Shadow" style={{ backgroundImage: `url('${imgShadow}')` }} />
        </div>
      </div>
      <div className="absolute flex h-[1119px] items-center justify-center left-[89px] top-[71px] w-[745px]">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <div className="bg-center bg-contain bg-no-repeat h-[1119px] w-[745px]" data-name="mainphoto" style={{ backgroundImage: `url('${imgShadow}')` }} />
        </div>
      </div>
    </div>
  );
}

export default function MamaLandingPage() {
  return (
    <div className="bg-[#fffdfc] relative size-full" data-name="mama/ landing page">
      <Group236 />
      <div className="absolute bg-[#305cde] h-1 rounded-[100px] top-[78px] translate-x-[-50%] w-[60px]" style={{ left: "calc(50% - 278px)" }} />
      <Frame235 />
      <div className="absolute bg-center bg-cover bg-no-repeat left-[74px] size-[100px] top-[9px]" data-name="image 14" style={{ backgroundImage: `url('${imgImage14}')` }} />
      <Group234 />
      <div className="[text-shadow:rgba(0,0,0,0.15)_0px_2px_6px,rgba(0,0,0,0.3)_0px_1px_2px] absolute flex flex-col font-['Lora:SemiBold',_sans-serif] font-semibold justify-center leading-[60px] right-[93px] text-[#010221] text-[54px] text-nowrap text-right tracking-[2.16px] translate-y-[-50%] whitespace-pre" style={{ top: "calc(50% - 51px)" }}>
        <p className="mb-0">
          <span className="font-['Lora:SemiBold_Italic',_sans-serif] font-semibold italic text-[#305cde]">Empowering</span>
          <span>{` learners.`}</span>
        </p>
        <p>One lesson at a time</p>
      </div>
      <div className="absolute flex flex-col font-['Lato:SemiBold',_sans-serif] justify-center leading-[0] not-italic right-[94px] text-[#1e003c] text-[24px] text-right tracking-[0.96px] translate-y-[-50%] w-[611px]" style={{ top: "calc(50% + 57px)" }}>
        <p className="leading-[40px]">
          <span>{`Discover engaging, student-first learning experiences with `}</span>
          <span className="text-[#305cde]">{`Ms Adefoluso Adekunle `}</span>
        </p>
      </div>
      <Group235 />
      <Photo />
    </div>
  );
}