import { motion, useInView } from 'framer-motion';
import { useRef, useState } from 'react';
import { Star, Quote, ChevronLeft, ChevronRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function TestimonialsSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const testimonials = [
    {
      name: 'Jennifer Walsh',
      title: 'Business Owner',
      company: 'Walsh Enterprises',
      image: 'professional woman business',
      rating: 5,
      text: 'Sterling & Associates helped us navigate a complex corporate acquisition. Their expertise and attention to detail were exceptional. I wouldn\'t trust anyone else with our legal matters.',
      case: 'Corporate Law',
    },
    {
      name: 'Robert Martinez',
      title: 'Accident Victim',
      company: 'Personal Injury Client',
      image: 'professional man testimonial',
      rating: 5,
      text: 'After my accident, I felt lost and overwhelmed. David Chen and his team fought tirelessly for me and secured a settlement that exceeded my expectations. They truly care about their clients.',
      case: 'Personal Injury',
    },
    {
      name: 'Lisa Thompson',
      title: 'Homeowner',
      company: 'Real Estate Client',
      image: 'professional woman homeowner',
      rating: 5,
      text: 'Sarah Martinez made our home purchase seamless. Her expertise in real estate law saved us from potential issues and gave us peace of mind throughout the process.',
      case: 'Real Estate',
    },
    {
      name: 'Michael Chen',
      title: 'Defendant',
      company: 'Criminal Defense Client',
      image: 'professional man client',
      rating: 5,
      text: 'Michael Thompson\'s defense strategy was brilliant. He believed in my innocence when others didn\'t and secured a complete dismissal of all charges. I owe him everything.',
      case: 'Criminal Defense',
    },
  ];

  const nextTestimonial = () => {
    setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section id="testimonials" className="py-20 bg-gradient-to-br from-[var(--warm-gray)] to-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[var(--regal-navy)] mb-6"
          >
            Client Success Stories
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-lg text-[var(--muted-foreground)] max-w-3xl mx-auto leading-relaxed"
          >
            Don't just take our word for it. Here's what our clients have to say about their experience 
            working with Sterling & Associates.
          </motion.p>
        </motion.div>

        {/* Main Testimonial Display */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="relative max-w-4xl mx-auto mb-12"
        >
          <div className="bg-white rounded-2xl p-8 lg:p-12 shadow-2xl border border-[var(--border)] relative overflow-hidden">
            {/* Quote decoration */}
            <div className="absolute top-6 right-6 w-16 h-16 bg-gradient-to-br from-[var(--regal-purple)]/20 to-transparent rounded-full flex items-center justify-center">
              <Quote className="w-8 h-8 text-[var(--regal-purple)]" />
            </div>

            <motion.div
              key={currentTestimonial}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.5 }}
              className="flex flex-col lg:flex-row items-center lg:items-start gap-8"
            >
              {/* Client Photo */}
              <div className="flex-shrink-0">
                <div className="w-24 h-24 lg:w-32 lg:h-32 rounded-full overflow-hidden border-4 border-[var(--regal-gold)]/30">
                  <ImageWithFallback
                    src={`https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face`}
                    alt={testimonials[currentTestimonial].name}
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 text-center lg:text-left">
                {/* Rating */}
                <div className="flex justify-center lg:justify-start mb-4">
                  {[...Array(testimonials[currentTestimonial].rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-[var(--regal-gold)] fill-current" />
                  ))}
                </div>

                {/* Testimonial Text */}
                <blockquote className="text-lg lg:text-xl text-[var(--regal-navy)] leading-relaxed mb-6 italic">
                  "{testimonials[currentTestimonial].text}"
                </blockquote>

                {/* Client Info */}
                <div className="space-y-1">
                  <div className="font-semibold text-[var(--regal-navy)]">
                    {testimonials[currentTestimonial].name}
                  </div>
                  <div className="text-[var(--muted-foreground)]">
                    {testimonials[currentTestimonial].title}
                  </div>
                  <div className="inline-block px-3 py-1 bg-[var(--regal-purple)]/10 text-[var(--regal-purple)] rounded-full text-sm font-medium">
                    {testimonials[currentTestimonial].case}
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Navigation Buttons */}
            <div className="flex justify-center lg:justify-end mt-8 space-x-4">
              <motion.button
                onClick={prevTestimonial}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                className="w-12 h-12 rounded-full bg-[var(--regal-purple)]/10 flex items-center justify-center text-[var(--regal-purple)] hover:bg-[var(--regal-purple)] hover:text-white transition-all duration-200"
              >
                <ChevronLeft className="w-5 h-5" />
              </motion.button>
              <motion.button
                onClick={nextTestimonial}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                className="w-12 h-12 rounded-full bg-[var(--regal-purple)]/10 flex items-center justify-center text-[var(--regal-purple)] hover:bg-[var(--regal-purple)] hover:text-white transition-all duration-200"
              >
                <ChevronRight className="w-5 h-5" />
              </motion.button>
            </div>
          </div>
        </motion.div>

        {/* Testimonial Indicators */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="flex justify-center space-x-2 mb-12"
        >
          {testimonials.map((_, index) => (
            <motion.button
              key={index}
              onClick={() => setCurrentTestimonial(index)}
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }}
              className={`w-3 h-3 rounded-full transition-all duration-200 ${
                index === currentTestimonial
                  ? 'bg-[var(--regal-purple)]'
                  : 'bg-[var(--regal-purple)]/30 hover:bg-[var(--regal-purple)]/50'
              }`}
            />
          ))}
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1 }}
          className="grid grid-cols-1 sm:grid-cols-3 gap-8"
        >
          {[
            { number: '4.9/5', label: 'Client Rating', sublabel: 'Based on 500+ reviews' },
            { number: '98%', label: 'Client Satisfaction', sublabel: 'Would recommend us' },
            { number: '24hrs', label: 'Response Time', sublabel: 'Average initial response' },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 1.2 + index * 0.1 }}
              whileHover={{ y: -5 }}
              className="text-center p-6 bg-white rounded-xl shadow-lg border border-[var(--border)] hover:shadow-xl transition-all duration-300"
            >
              <div className="text-3xl font-bold text-[var(--regal-purple)] mb-2">{stat.number}</div>
              <div className="text-lg font-semibold text-[var(--regal-navy)] mb-1">{stat.label}</div>
              <div className="text-sm text-[var(--muted-foreground)]">{stat.sublabel}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}