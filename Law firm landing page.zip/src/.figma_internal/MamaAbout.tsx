import svgPaths from "./svg-p0x47w102y";
import imgImage14 from "figma:asset/41836e67122912031230d1488bff7f336558878e.png";

function Frame236() {
  return (
    <div className="absolute box-border content-stretch flex font-['Lato:Bold',_sans-serif] gap-9 items-center justify-start leading-[0] left-[387px] not-italic p-[8px] text-[18px] text-center text-nowrap top-10 tracking-[0.36px]">
      <div className="flex flex-col justify-center relative shrink-0 text-[#1e003c]">
        <p className="leading-[normal] text-nowrap whitespace-pre">Home</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-[#305cde]">
        <p className="leading-[normal] text-nowrap whitespace-pre">About</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-[#1e003c]">
        <p className="leading-[normal] text-nowrap whitespace-pre">Courses</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-[#1e003c]">
        <p className="leading-[normal] text-nowrap whitespace-pre">Testimonials</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-[#1e003c]">
        <p className="leading-[normal] text-nowrap whitespace-pre">Contact</p>
      </div>
    </div>
  );
}

function ArrowForward() {
  return (
    <div className="relative shrink-0 size-6" data-name="arrow_forward">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="arrow_forward">
          <path d={svgPaths.p54e7200} fill="var(--fill-0, #FFFDFC)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function Frame234() {
  return (
    <div className="absolute bg-[#1e003c] box-border content-stretch flex gap-2.5 inset-[2.38%_9.14%] items-center justify-center px-[50px] py-[18px] rounded-[100px]">
      <div className="flex flex-col font-['Lato:Bold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#fffdfc] text-[20px] text-center text-nowrap tracking-[0.4px]">
        <p className="leading-[normal] whitespace-pre">Let’s Talk</p>
      </div>
      <ArrowForward />
    </div>
  );
}

function Group234() {
  return (
    <div className="absolute h-[63px] right-[51px] top-[27px] w-[268px]">
      <Frame234 />
    </div>
  );
}

function Group237() {
  return (
    <div className="absolute bottom-0 h-[640px] left-[-192px] w-[428px]">
      <div className="absolute inset-[-12.67%_-20.21%_-12.7%_-19.2%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 598 804">
          <g id="Group 237" opacity="0.05">
            <path d={svgPaths.p359c7380} fill="var(--stroke-0, #1E003C)" id="Vector 18" />
            <path d={svgPaths.p5922c00} fill="var(--stroke-0, #1E003C)" id="Vector 19" />
            <path d={svgPaths.p3e74e600} fill="var(--stroke-0, #1E003C)" id="Vector 20" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group238() {
  return (
    <div className="h-[640px] relative w-[428px]">
      <div className="absolute inset-[-12.67%_-20.21%_-12.7%_-19.2%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 598 804">
          <g id="Group 238" opacity="0.05">
            <path d={svgPaths.p359c7380} fill="var(--stroke-0, #1E003C)" id="Vector 18" />
            <path d={svgPaths.p5922c00} fill="var(--stroke-0, #1E003C)" id="Vector 19" />
            <path d={svgPaths.p3e74e600} fill="var(--stroke-0, #1E003C)" id="Vector 20" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ArrowForward1() {
  return (
    <div className="relative shrink-0 size-6" data-name="arrow_forward">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="arrow_forward">
          <path d={svgPaths.p54e7200} fill="var(--fill-0, #FFFDFC)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function Frame235() {
  return (
    <div className="absolute bg-[#5a7be7] box-border content-stretch flex gap-2.5 inset-[2.38%_-9.7%] items-center justify-center px-[50px] py-[18px] rounded-[100px]">
      <div className="flex flex-col font-['Lato:Bold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#fffdfc] text-[20px] text-center text-nowrap tracking-[0.4px]">
        <p className="leading-[normal] whitespace-pre">Let’s Learn Together</p>
      </div>
      <ArrowForward1 />
    </div>
  );
}

function Group235() {
  return (
    <div className="absolute h-[63px] right-[94px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] translate-y-[-50%] w-[268px]" style={{ top: "calc(50% + 377.5px)" }}>
      <Frame235 />
    </div>
  );
}

function ArrowForward2() {
  return (
    <div className="relative shrink-0 size-6" data-name="arrow_forward">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="arrow_forward">
          <path d={svgPaths.p54e7200} fill="var(--fill-0, #FFFDFC)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function Frame237() {
  return (
    <div className="absolute bg-[#5a7be7] box-border content-stretch flex gap-2.5 inset-[2.38%_-8.58%] items-center justify-center px-[50px] py-[18px] rounded-[100px]">
      <div className="flex flex-col font-['Lato:Bold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#fffdfc] text-[20px] text-center text-nowrap tracking-[0.4px]">
        <p className="leading-[normal] whitespace-pre">What you can learn</p>
      </div>
      <ArrowForward2 />
    </div>
  );
}

function Group239() {
  return (
    <div className="absolute h-[63px] right-[442px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] translate-y-[-50%] w-[268px]" style={{ top: "calc(50% + 377.5px)" }}>
      <Frame237 />
    </div>
  );
}

export default function MamaAbout() {
  return (
    <div className="bg-[#fffdfc] relative size-full" data-name="mama/about">
      <div className="absolute bg-[#f5f5fa] h-[542px] rounded-lg top-[302px] translate-x-[-50%] w-[988px]" style={{ left: "calc(50% - 1px)" }} />
      <div className="absolute bg-[#305cde] h-1 left-[478px] rounded-[100px] top-[78px] w-[60px]" />
      <Frame236 />
      <div className="absolute bg-center bg-cover bg-no-repeat left-[52px] size-[100px] top-[9px]" data-name="image 14" style={{ backgroundImage: `url('${imgImage14}')` }} />
      <Group234 />
      <div className="absolute flex flex-col font-['Lora:SemiBold',_sans-serif] font-semibold justify-center leading-[0] text-[#305cde] text-[54px] text-nowrap text-right top-[248px] tracking-[2.16px] translate-x-[-100%] translate-y-[-50%]" style={{ left: "calc(50% + 489px)" }}>
        <p className="font-bold leading-[60px] whitespace-pre">
          <span className="font-['Lora:Bold_Italic',_sans-serif] italic">Inspiring</span>
          <span className="font-['Lora:Bold',_sans-serif]"> </span>
          <span className="font-['Lora:Bold',_sans-serif] text-[#010221]">young minds to</span>
          <span className="font-['Lora:Bold',_sans-serif]"> </span>
          <span className="font-['Lora:Bold_Italic',_sans-serif] italic">greatness!</span>
        </p>
      </div>
      <Group237 />
      <div className="absolute bottom-0 flex h-[640px] items-center justify-center right-[-200px] w-[428px]">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <Group238 />
        </div>
      </div>
      <div className="absolute flex flex-col font-['Lato:Medium',_sans-serif] justify-center leading-[0] not-italic text-[#000000] text-[24px] top-[574px] tracking-[0.48px] translate-y-[-50%] w-[956px]" style={{ left: "calc(50% - 478px)" }}>
        <p className="leading-[36px] mb-0">
          <span>{`Hello! I’m `}</span>
          <span className="font-['Lato:Medium_Italic',_sans-serif] italic text-[#305cde]">Ms. Adekunle</span>
          <span>{`, and I’ve had the joy of teaching for over `}</span>
          <span className="font-['Lato:Medium_Italic',_sans-serif] italic text-[#305cde]">twenty years</span>. I specialize in teaching Key Stage 2 (KS2) subjects especially geography, and I believe with all my heart that no child is ever “dumb.” Every learner has their own spark, their own style, and I love discovering just how to bring that out.
        </p>
        <p className="leading-[36px] mb-0">&nbsp;</p>
        <p className="leading-[36px] mb-0">In my classroom, it’s not just about the books – it’s about finding the fun, the focus, and the real-world magic that makes learning exciting. I take the time to really get to know each of my students, finding their unique interests and weaving them into lessons that make even the toughest concepts easy to understand.</p>
        <p className="leading-[36px] mb-0">&nbsp;</p>
        <p className="leading-[36px]">
          <span>{`I’m `}</span>
          <span className="font-['Lato:Medium_Italic',_sans-serif] italic text-[#305cde]">passionate</span>
          <span>{` about helping my students build confidence, good behaviour, and a love for learning that sticks with them long after they leave my classroom. I believe learning should be a joyful `}</span>
          <span className="font-['Lato:Medium_Italic',_sans-serif] italic text-[#305cde]">adventure</span>, and I’m here to guide every student through it, one engaging lesson at a time.
        </p>
      </div>
      <Group235 />
      <Group239 />
      <div className="absolute flex flex-col font-['Lato:Bold',_sans-serif] justify-center leading-[0] not-italic right-[575.5px] text-[#1e003c] text-[14px] text-center text-nowrap tracking-[0.28px] translate-x-[50%] translate-y-[-50%]" style={{ top: "calc(50% + 425.5px)" }}>
        <p className="leading-[normal] whitespace-pre">{`Let’s see how i can help `}</p>
      </div>
      <div className="absolute flex flex-col font-['Lato:Bold',_sans-serif] justify-center leading-[0] not-italic right-[227.5px] text-[#1e003c] text-[14px] text-center text-nowrap tracking-[0.28px] translate-x-[50%] translate-y-[-50%]" style={{ top: "calc(50% + 429.5px)" }}>
        <p className="leading-[normal] whitespace-pre">Every learner deserves a confident start</p>
      </div>
      <div className="absolute flex flex-col font-['Lato:Bold',_sans-serif] justify-center leading-[0] not-italic right-[185px] text-[#1e003c] text-[14px] text-center text-nowrap top-[107.5px] tracking-[0.28px] translate-x-[50%] translate-y-[-50%]">
        <p className="leading-[normal] whitespace-pre">Want to discuss your learning?</p>
      </div>
      <div className="absolute h-[183.5px] left-[228.5px] top-[489px] w-[974.5px]">
        <div className="absolute bottom-[-0.27%] left-0 right-0 top-[-0.27%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 975 185">
            <path d="M0 1H974.5M0 184.5H974.5" id="Vector 21" stroke="var(--stroke-0, #1E003C)" strokeOpacity="0.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}