import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { Scale, Heart, Zap, Shield } from 'lucide-react';

export function AboutSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  const values = [
    {
      icon: Scale,
      title: 'Justice',
      description: 'We believe in fighting for what\'s right, ensuring every client receives fair representation and equal treatment under the law.',
    },
    {
      icon: Heart,
      title: 'Compassion',
      description: 'Legal challenges are personal. We approach every case with empathy, understanding the human impact of legal decisions.',
    },
    {
      icon: Zap,
      title: 'Excellence',
      description: 'Our track record speaks for itself. We consistently deliver exceptional results through meticulous preparation and strategic thinking.',
    },
    {
      icon: Shield,
      title: 'Integrity',
      description: 'Trust is the foundation of our practice. We maintain the highest ethical standards in all our professional relationships.',
    },
  ];

  return (
    <section id="about" className="py-20 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[var(--regal-navy)] mb-6"
          >
            Built on a Foundation of
            <span className="block text-[var(--regal-purple)]">Trust and Excellence</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-lg text-[var(--muted-foreground)] max-w-3xl mx-auto leading-relaxed"
          >
            Since 1992, Sterling & Associates has been the trusted legal partner for individuals, 
            families, and businesses facing complex legal challenges. Our unwavering commitment to 
            justice and client success has earned us recognition as one of the premier law firms in the region.
          </motion.p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left Column - Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="space-y-6"
          >
            <div className="prose prose-lg max-w-none">
              <p className="text-[var(--muted-foreground)] leading-relaxed">
                Our firm was founded on the principle that exceptional legal representation should be 
                accessible to all. We combine decades of experience with innovative legal strategies 
                to deliver results that exceed expectations.
              </p>
              <p className="text-[var(--muted-foreground)] leading-relaxed">
                From complex corporate litigation to personal injury cases, our team of seasoned 
                attorneys brings passion, expertise, and an unwavering commitment to justice to 
                every matter we handle.
              </p>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="bg-gradient-to-r from-[var(--regal-purple)]/5 to-[var(--regal-gold)]/5 p-6 rounded-xl border border-[var(--regal-purple)]/10"
            >
              <h3 className="text-xl font-semibold text-[var(--regal-navy)] mb-3">Our Mission</h3>
              <p className="text-[var(--muted-foreground)] italic">
                "To provide exceptional legal services while maintaining the highest standards of 
                professional integrity, ensuring our clients receive the justice they deserve."
              </p>
            </motion.div>
          </motion.div>

          {/* Right Column - Values Grid */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="grid grid-cols-1 sm:grid-cols-2 gap-6"
          >
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 1 + index * 0.1 }}
                whileHover={{ y: -5, scale: 1.02 }}
                className="bg-white p-6 rounded-xl shadow-lg border border-[var(--border)] hover:shadow-xl transition-all duration-300 group"
              >
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[var(--regal-purple)] to-[var(--regal-light-purple)] flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <value.icon className="w-6 h-6 text-white" />
                </div>
                <h4 className="text-lg font-semibold text-[var(--regal-navy)] mb-2">{value.title}</h4>
                <p className="text-[var(--muted-foreground)] text-sm leading-relaxed">{value.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Statistics Row */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1.2 }}
          className="mt-20 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {[
            { number: '98%', label: 'Success Rate', sublabel: 'Cases won or settled favorably' },
            { number: '$50M+', label: 'Recovered', sublabel: 'For our clients' },
            { number: '30+', label: 'Attorneys', sublabel: 'Expert legal professionals' },
            { number: '24/7', label: 'Support', sublabel: 'Available when you need us' },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 1.4 + index * 0.1 }}
              whileHover={{ y: -5 }}
              className="text-center p-6 rounded-xl bg-gradient-to-br from-[var(--warm-gray)] to-white border border-[var(--border)] hover:shadow-lg transition-all duration-300"
            >
              <div className="text-3xl font-bold text-[var(--regal-purple)] mb-2">{stat.number}</div>
              <div className="text-lg font-semibold text-[var(--regal-navy)] mb-1">{stat.label}</div>
              <div className="text-sm text-[var(--muted-foreground)]">{stat.sublabel}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}